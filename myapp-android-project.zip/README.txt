مشروع Android جاهز: MIND AI – العقل الذكي

للحصول على APK:
1) GitHub: ارفع المحتوى إلى مستودع، ثم Actions > Build APK > Run workflow، ونزّل app-debug-apk من Artifacts.
2) Android Studio: افتح المجلد ثم Build > Build APK(s).
3) أو من الطرفية (مع تثبيت Gradle 8.5 و JDK 17): gradle assembleDebug
   المخرج: app/build/outputs/apk/debug/app-debug.apk
